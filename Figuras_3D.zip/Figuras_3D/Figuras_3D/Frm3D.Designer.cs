﻿namespace Figuras_3D
{
    partial class Frm3D
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSides = new System.Windows.Forms.TextBox();
            this.Lados = new System.Windows.Forms.Label();
            this.btnDraw = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.picCanvas = new System.Windows.Forms.PictureBox();
            this.scaleBar = new System.Windows.Forms.TrackBar();
            this.btnRotateXPos = new System.Windows.Forms.Button();
            this.btnRotateXNeg = new System.Windows.Forms.Button();
            this.btnRotateYNeg = new System.Windows.Forms.Button();
            this.btnRotateYPos = new System.Windows.Forms.Button();
            this.btnRotateZNeg = new System.Windows.Forms.Button();
            this.btnRotateZPos = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleBar)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSides
            // 
            this.txtSides.Location = new System.Drawing.Point(67, 60);
            this.txtSides.Name = "txtSides";
            this.txtSides.Size = new System.Drawing.Size(100, 22);
            this.txtSides.TabIndex = 0;
            // 
            // Lados
            // 
            this.Lados.AutoSize = true;
            this.Lados.Location = new System.Drawing.Point(69, 35);
            this.Lados.Name = "Lados";
            this.Lados.Size = new System.Drawing.Size(45, 16);
            this.Lados.TabIndex = 1;
            this.Lados.Text = "Lados";
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(51, 153);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(75, 23);
            this.btnDraw.TabIndex = 2;
            this.btnDraw.Text = "Dibujar";
            this.btnDraw.UseVisualStyleBackColor = true;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(51, 217);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Salir";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(157, 153);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "Resetear";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // picCanvas
            // 
            this.picCanvas.Location = new System.Drawing.Point(355, 108);
            this.picCanvas.Name = "picCanvas";
            this.picCanvas.Size = new System.Drawing.Size(556, 366);
            this.picCanvas.TabIndex = 5;
            this.picCanvas.TabStop = false;
            // 
            // scaleBar
            // 
            this.scaleBar.Location = new System.Drawing.Point(355, 26);
            this.scaleBar.Name = "scaleBar";
            this.scaleBar.Size = new System.Drawing.Size(556, 56);
            this.scaleBar.TabIndex = 6;
            this.scaleBar.Scroll += new System.EventHandler(this.scaleBar_Scroll);
            // 
            // btnRotateXPos
            // 
            this.btnRotateXPos.Location = new System.Drawing.Point(67, 307);
            this.btnRotateXPos.Name = "btnRotateXPos";
            this.btnRotateXPos.Size = new System.Drawing.Size(75, 23);
            this.btnRotateXPos.TabIndex = 7;
            this.btnRotateXPos.Text = "X pos";
            this.btnRotateXPos.UseVisualStyleBackColor = true;
            this.btnRotateXPos.Click += new System.EventHandler(this.btnRotateXPos_Click);
            // 
            // btnRotateXNeg
            // 
            this.btnRotateXNeg.Location = new System.Drawing.Point(182, 307);
            this.btnRotateXNeg.Name = "btnRotateXNeg";
            this.btnRotateXNeg.Size = new System.Drawing.Size(75, 23);
            this.btnRotateXNeg.TabIndex = 8;
            this.btnRotateXNeg.Text = "X neg";
            this.btnRotateXNeg.UseVisualStyleBackColor = true;
            this.btnRotateXNeg.Click += new System.EventHandler(this.btnRotateXNeg_Click);
            // 
            // btnRotateYNeg
            // 
            this.btnRotateYNeg.Location = new System.Drawing.Point(182, 366);
            this.btnRotateYNeg.Name = "btnRotateYNeg";
            this.btnRotateYNeg.Size = new System.Drawing.Size(75, 23);
            this.btnRotateYNeg.TabIndex = 9;
            this.btnRotateYNeg.Text = "Y neg";
            this.btnRotateYNeg.UseVisualStyleBackColor = true;
            this.btnRotateYNeg.Click += new System.EventHandler(this.btnRotateYNeg_Click);
            // 
            // btnRotateYPos
            // 
            this.btnRotateYPos.Location = new System.Drawing.Point(67, 366);
            this.btnRotateYPos.Name = "btnRotateYPos";
            this.btnRotateYPos.Size = new System.Drawing.Size(75, 23);
            this.btnRotateYPos.TabIndex = 10;
            this.btnRotateYPos.Text = "Y pos";
            this.btnRotateYPos.UseVisualStyleBackColor = true;
            this.btnRotateYPos.Click += new System.EventHandler(this.btnRotateYPos_Click);
            // 
            // btnRotateZNeg
            // 
            this.btnRotateZNeg.Location = new System.Drawing.Point(182, 431);
            this.btnRotateZNeg.Name = "btnRotateZNeg";
            this.btnRotateZNeg.Size = new System.Drawing.Size(75, 23);
            this.btnRotateZNeg.TabIndex = 11;
            this.btnRotateZNeg.Text = "Z neg";
            this.btnRotateZNeg.UseVisualStyleBackColor = true;
            this.btnRotateZNeg.Click += new System.EventHandler(this.btnRotateZNeg_Click);
            // 
            // btnRotateZPos
            // 
            this.btnRotateZPos.Location = new System.Drawing.Point(67, 431);
            this.btnRotateZPos.Name = "btnRotateZPos";
            this.btnRotateZPos.Size = new System.Drawing.Size(75, 23);
            this.btnRotateZPos.TabIndex = 12;
            this.btnRotateZPos.Text = "Z pos";
            this.btnRotateZPos.UseVisualStyleBackColor = true;
            this.btnRotateZPos.Click += new System.EventHandler(this.btnRotateZPos_Click);
            // 
            // Frm3D
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 535);
            this.Controls.Add(this.btnRotateZPos);
            this.Controls.Add(this.btnRotateZNeg);
            this.Controls.Add(this.btnRotateYPos);
            this.Controls.Add(this.btnRotateYNeg);
            this.Controls.Add(this.btnRotateXNeg);
            this.Controls.Add(this.btnRotateXPos);
            this.Controls.Add(this.scaleBar);
            this.Controls.Add(this.picCanvas);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDraw);
            this.Controls.Add(this.Lados);
            this.Controls.Add(this.txtSides);
            this.Name = "Frm3D";
            this.Text = "Frm3D";
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSides;
        private System.Windows.Forms.Label Lados;
        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.PictureBox picCanvas;
        private System.Windows.Forms.TrackBar scaleBar;
        private System.Windows.Forms.Button btnRotateXPos;
        private System.Windows.Forms.Button btnRotateXNeg;
        private System.Windows.Forms.Button btnRotateYNeg;
        private System.Windows.Forms.Button btnRotateYPos;
        private System.Windows.Forms.Button btnRotateZNeg;
        private System.Windows.Forms.Button btnRotateZPos;
    }
}